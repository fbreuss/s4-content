### SETUP
- enable "Advanced Hotkeys" in "SU -> Settings -> S4" or in the in-game-settings (HD Patch) "External -> Hotkeys".
- on first startup of S4, a file "default.json" is created in this folder, containing default hotkeys
- if you remove "default.json", it will be recreated on next S4-startup
- hotkeys are reloaded automatically when a new game is loaded, when pressing the "onReloadHotkeysKey" (default = "F5") or in the in-game-settings (HD Patch) "External -> Hotkeys".




### CUSTOMIZATION
The file "default.json" is loaded on each S4 startup.
If any error occurs, there is a message box. Otherwise the hotkeys were loaded successfully. Also check the log.txt on errors.

CHANGE HOTKEYS: go to said file and change the "_key" field and add/remove new "actions".

NOTES:
- You can give the same key multiple different actions depending on the hotkey-combination (e.g. "tab" does something different than "tab + shift")
- Currently there is only a single "combination"-key per "functionToExecute" supported (e.g. *NOT* Shift+Ctrl+D).
- For the same "_key" use the same "combination"-key only once.
- Combine all actions one "_key" should have into one hotkey.
- You can also change extra mouse buttons (VK_XBUTTON1 and VK_XBUTTON2).
- If "IgnoreS4SpecialKeys" is enabled, even special keys of default S4 are disabled (e.g. ctrl+S) s.t. you can remap them yourself (the initial default.json file has the same settings as default S4, e.g. ctrl+S still saves the game, but you can now assign a custom hotkey to it).
- Known S4 keys which are NOT deactivated yet, even when "IgnoreS4SpecialKeys" is enabled: [Esc, F1, F2, F3, F4, F6, F7, Enter]

FILE STRUCTURE
The basic structure can be seen below, see default.json for an example on how to set different keys.

Parameters:
  - "_redCrossCombinationButtonToSelectAllWoundedUnits": any <Virtual-Key Code>, see below. When this button is pressed while you click on a Red Cross (or use the S4-default-hotkey Delete), all wounded units are selected (<100% HP, instead of <50% if not pressed).
  - "_concreteSelectionCombinationButtonToSelectOnlyEquivalentUnits": any <Virtual-Key Code>, see below. When this button is pressed while you alt-/shift-click on any entities, only exactly matching entities are selected (e.g. you click on a lvl3 bowman and only other lvl3 bowman are selected, no bowmen lvl1 or lvl2).
  - "_repeatedBuildingPlacement": any <Virtual-Key Code>, see below. When this button is pressed while a building is being placed, you can place the same buildingtype without having to select it again in the menu.
  - "hotkeys": this is a list [] of hotkey-objects {} (for more details see https://www.json.org/json-en.html). Each hotkey has a "_key" which can trigger some (in a list) "actions" ("functionToExecute"), depending on the action's "combination". If the "combination" is fulfilled, the "functionToExecute" is executed.
  - "_key": any <Virtual-Key Code>, see below.
  - "combination": one *of a few* <Virtual-Key Code>, see below.
  - "functionToExecute": one of <Function>, see below.

Values:
  - <bool>: one of [true, false, "true", "false"]
  - <Virtual-Key Code>: any "Virtual-Key Code" (column "Constant") from this website https://learn.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes .
    If the column is empty, like for normal keys 0-9 and A-Z, use the key's digit/sign instead, e.g. key "A" has <Virtual-Key Code> = "A" as well, NOT "VK_A".
    For "combination" however, only these are valid combinations: ["", "VK_SHIFT", "VK_LSHIFT", "VK_RSHIFT", "VK_CONTROL", "VK_LCONTROL", "VK_RCONTROL", "VK_MENU", "VK_LMENU", "VK_RMENU"]. E.g. "VK_SHIFT" is any shift key, "VK_LSHIFT" specifically only the left shift key. If it's an empty string (""), no combination is needed.
    "VK_MENU" is the alt-key, see above website for more documentation.
    There are also Virtual-Key Codes for Mouse buttons (VK_XBUTTON1 and VK_XBUTTON2).
    NOTE that there are still some Hotkeys from S4 (see NOTES) and Windows which are not deactivated yet, e.g. "Esc" will ask you if you want to exit the game, even if you assign some Hotkey to it, or "Alt+F4" will kill your application...
  - <Function>: any string from the file "./Functions_Hotkeys.txt" (in this same directory).

BASIC STRUCTURE
{ "_redCrossCombinationButtonToSelectAllWoundedUnits": "<Virtual-Key Code>",
  "_concreteSelectionCombinationButtonToSelectOnlyEquivalentUnits": "<Virtual-Key Code>",
  "_repeatedBuildingPlacement": "VK_CONTROL",
  "hotkeys": [
  { "_key": "<Virtual-Key Code>", "actions": [
    { "combination": "<Virtual-Key Code OR empty>", "functionToExecute": "<Function>" }
   ] },
  { "_key": "<Virtual-Key Code>", "actions": [
    { "combination": "<Virtual-Key Code OR empty>", "functionToExecute": "<Function>" },
    { "combination": "<Virtual-Key Code OR empty>", "functionToExecute": "<Function>" },
    { "combination": "<Virtual-Key Code OR empty>", "functionToExecute": "<Function>" }
   ] },
   ...
  ] }





### COMMON ERRORS:

SYNTAX ERRORS:
  BEFORE REPORTING ANY ERRORS, you should use a website to test if the structure of the file "default.json" is valid.
    E.g. use this one which highlights all errors with an explanation of what is missing. Copy the content of default.json into the website and click "Validate JSON". If it does NOT say "JSON is valid!" afterwards, you have an error:
      https://jsonlint.com/
  - "JSON parsing error : ..."
  - "JSON parsing error : ... at line L, column C: syntax error while parsing value - unexpected ']'; expected '[', '{' or a literal"
  - "JSON parsing error : ... at line L, column C: syntax error while parsing value - unexpected '{'; expected ']'"
  - etc...
  -> all these errors are syntax-errors and can be fixed by using said website above

MESSAGE BOX POPS UP:
  - it usually says what you should do
  - otherwise check the ./log.txt file (reload it if it was still open), ensure that there are no ERRORs
  - you should also fix all WARNINGs

ASI LOADER ERROR:
  please report this error and upload "default.json" on the SU-discord server under Development/s4-Hotkeys

STILL NOT WORKING:
  - delete/rename the "default.json" file and restart S4 (or whole PC), it will regenerate it with default settings...
  - report this error and upload "default.json" on the SU-discord server under Development/s4-Hotkeys or

PERFORMANCE:
  - if you think hotkeys slow down your PC, especially while DEBUGGING, try disabling "Use Mouse Hook" (disabled by default), otherwise try changing "Use Windows Hook", enabled should be faster though (in the in-game-settings (HD Patch) "External -> Hotkeys" or via Registry entry "UseWindowsHook" (see below)).
  If enabled (1, recommended), it will use the default Windows-Hook, which should be much more performant and allows e.g. keeping a button pressed or pressing multiple hotkeys at the same time. Otherwise, if disabled (0), you can only have one hotkey pressed at a time as it uses a different technique.

UNEXPECTED RESULTS:
  - if some default S4 button does not what you expect it to do and you are sure it's not your faulty default.json-file, change "Ignore S4 Special Keys" (in the in-game-settings (HD Patch) "External -> Hotkeys" or via Registry entry "IgnoreS4SpecialKeys" (see below).





### CHANGING REGISTRY ENTRIES BY HAND
If you don't use HD patch, changing settings is a bit more tricky at the moment.
Note: these registry entries are only created after running S4 once.

Press "Windows-Key + R"
Insert "regedit"
Press "Enter"
Navigate to "Computer\HKEY_CURRENT_USER\Software\Settlers United\S4\Game"
Click on the folder "Game"
Double-click the said key (column "Name", e.g. "IgnoreS4SpecialKeys")
Insert either 0 or 1 as value (1 means "enabled")
Press "OK"
Restart S4

See https://www.bleepingcomputer.com/tutorials/how-to-use-the-windows-registry-editor/





### USEFUL LINKS
Intro to json: https://www.json.org/json-en.html
Check your json file: https://jsonlint.com/
Virtual-Key Codes: https://learn.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes
Deutsches Keyboard Layout: https://kbdlayout.info/KBDGR/virtualkeys
US English Keyboard Layout: https://kbdlayout.info/kbdusa/virtualkeys
How to change Registry entries: https://www.bleepingcomputer.com/tutorials/how-to-use-the-windows-registry-editor/


