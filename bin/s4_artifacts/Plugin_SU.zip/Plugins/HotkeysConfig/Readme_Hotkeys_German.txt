### SETUP
- aktiviere "Erweiterte Hotkeys" unter "SU -> Einstellungen -> S4" oder in den Einstellungen im Spiel (HD Patch) unter "External -> Hotkeys".
- beim ersten Start von S4 wird in diesem Ordner eine Datei "default.json" erstellt, die Standard-Hotkeys enthält
- ist die Datei "default.json" gelöschen, wird sie beim nächsten S4-Start neu erstellt
- Hotkeys werden automatisch neu geladen, wenn ein neues Spiel geladen wird, wenn die "onReloadHotkeysKey" (Standard = "F5") gedrückt wird oder in den Einstellungen im Spiel (HD Patch) unter "External -> Hotkeys".





### ANPASSUNG DER HOTKEYS
Die Datei "default.json" wird bei jedem S4-Start geladen.
Wenn ein Fehler auftritt, wird eine Meldung angezeigt. Ansonsten wurden die Hotkeys erfolgreich geladen. Prüfen Sie auch die ./log.txt auf ERRORs.

HOTKEYS ÄNDERN: default.json öffnen, das Feld "_key" ändern bzw. die "actions" bearbeiten, hinzu oder entfernen.

HINWEISE:
- Es können der gleichen Taste je nach Tastenkombination mehrere verschiedene Aktionen zuweisen (z. B. bewirkt "tab" etwas anderes als "tab + shift")
- Zur Zeit wird nur eine einzige "combination"-Taste pro "functionToExecute" unterstützt (z.B. *NICHT* Umschalt+Strg+D).
- Für dieselbe "_key" darf die gleiche "combination"-Taste nur einmal verwendet werden.
- Alle Aktionen mit dem gleichen "_key" sollen zu einem Hotkey kombiniert werden.
- Erweiterte Maustasten können ebenfalls verwendet werden (VK_XBUTTON1 und VK_XBUTTON2).
- Wenn "IgnoreS4SpecialKeys" aktiviert ist, werden auch Spezial-Tasten(-Kombinationen) vom normalen S4 deaktiviert (z.B. Strg+S, Strg+1, etc). Diese Tasten können nun frei mit anderen Funktionalitäten belegt werden sowie deren ursprüngliche Funktionalität auf andere Tasten umgelegt werden. Das bereitgestellte default.json hat aber alle Tastenbelegungen wie im ursprünglichen S4 mit "Erweiterten Hotkeys" (also Strg+S speichert noch immer das Spiel, kann nun aber umbelegt werden).
- Bekannte S4 Tasten deren Standard-Funktion noch NICHT deaktiviert sind, auch wenn "IgnoreS4SpecialKeys" aktiviert ist: [Esc, F1, F2, F3, F4, F6, F7, Enter]

DATEISTRUKTUR
Die Grundstruktur ist unten zu sehen, ein Beispiel für die Festlegung verschiedener Schlüssel ist in default.json.

Parameter:
  - "_redCrossCombinationButtonToSelectAllWoundedUnits": ein beliebiger <Virtual-Key Code>, siehe unten. Wenn diese Taste gedrückt wird, während man auf ein Rotes Kreuz klickt (oder den S4-Standard-Hotkey Löschen verwendet), werden alle verwundeten Einheiten ausgewählt (<100% HP, anstelle von <50% wenn nicht gedrückt).
  - "_concreteSelectionCombinationButtonToSelectOnlyEquivalentUnits": ein beliebiger <Virtual-Key Code>, siehe unten. Wenn diese Taste gedrückt wird, während man mit Alt-/Shift-Klick auf eine beliebige Einheit klickt, werden nur genau passende Einheiten ausgewählt (z.B. klickt man auf einen lvl3-Bogenschützen und nur andere lvl3-Bogenschützen werden ausgewählt, keine Bogenschützen lvl1 oder lvl2).
  - "_repeatedBuildingPlacement": ein beliebiger <Virtual-Key Code>, siehe unten. Wenn diese Taste gedrückt wird, während ein Gebäude platziert wird, kann derselbe Gebäudetyp wiederholt platziert werden ohne ihn im Menü erneut auswählen zu müssen.
  - "Hotkeys": dies ist eine Liste [] von Hotkey-Objekten {} (für weitere Details siehe https://www.json.org/json-en.html). Jeder Hotkey hat einen "_key", der einige "actions" ("functionToExecute") auslösen kann, abhängig von der "combination" der Aktion. Wenn die "combination" erfüllt ist, wird die "functionToExecute" ausgeführt.
  - "_key": ein beliebiger <Virtual-Key Code>, siehe unten.
  - "combination": einer *von einigen wenigen* <Virtual-Key Code>, siehe unten.
  - "functionToExecute": eine von <Function>, siehe unten.
  
Werte:
  - <bool>: einer von [true, false, "true", "false"]
  - <Virtual-Key Code>: ein beliebiger "Virtual-Key Code" (Spalte "Constant") von dieser Website https://learn.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes .
    Wenn in der Spalte kein Eintrag ist, wie bei den normalen Tasten 0-9 und A-Z, soll stattdessen die Ziffer/das Zeichen der Taste verwendet werden, z.B. Taste "A" hat auch <Virtual-Key Code> = "A", NICHT "VK_A".
    Für "combination" sind jedoch nur diese Kombinationen gültig: ["", "VK_SHIFT", "VK_LSHIFT", "VK_RSHIFT", "VK_CONTROL", "VK_LCONTROL", "VK_RCONTROL", "VK_MENU", "VK_LMENU", "VK_RMENU"]. Z.B. "VK_SHIFT" ist eine beliebige Umschalttaste, "VK_LSHIFT" speziell nur die linke Umschalttaste. Wenn es ein leerer String ("") ist, wird keine Kombination benötigt.
    "VK_MENU" ist die Alt-Taste, siehe obige Website für weitere Informationen.
    Es gibt auch Virtual-Key-Codes für Maustasten (VK_XBUTTON1 und VK_XBUTTON2).
    WICHTIG: es gibt immer noch einige Hotkeys von S4 (siehe Hinweise) und Windows, die noch nicht deaktiviert sind, z.B. "Esc" öffnet noch immer das Verlassen Fenster, auch wenn ein Hotkey damit belegt worden ist, oder Alt+F4 beendet die Anwendung...
  - <Funktion>: ein beliebiger String aus der Datei "./Functions_Hotkeys.txt" (im selben Verzeichnis).
  

BASIC STRUCTURE
{ "_redCrossCombinationButtonToSelectAllWoundedUnits": "<Virtual-Key Code>",
  "_concreteSelectionCombinationButtonToSelectOnlyEquivalentUnits": "<Virtual-Key Code>",
  "_repeatedBuildingPlacement": "VK_CONTROL",
  "hotkeys": [
  { "_key": "<Virtual-Key Code>", "actions": [
    { "combination": "<Virtual-Key Code OR empty>", "functionToExecute": "<Function>" }
   ] },
  { "_key": "<Virtual-Key Code>", "actions": [
    { "combination": "<Virtual-Key Code OR empty>", "functionToExecute": "<Function>" },
    { "combination": "<Virtual-Key Code OR empty>", "functionToExecute": "<Function>" },
    { "combination": "<Virtual-Key Code OR empty>", "functionToExecute": "<Function>" }
   ] },
   ...
  ] }





### HÄUFIGE FEHLER:

SYNTAX-FEHLER:
  BEVOR SIE IRGENDEINE FEHLER MELDEN, sollten Sie eine Website verwenden, um zu testen, ob die Struktur der Datei "default.json" gültig ist.
    Verwenden Sie z.B. diese Website, die alle Fehler mit einer Erklärung der fehlenden Elemente aufzeigt. Kopieren Sie den Inhalt von default.json in die Website und klicken Sie auf "JSON validieren". Wenn danach NICHT "JSON is valid!" angezeigt wird, liegt ein Fehler vor:
      https://jsonlint.com/
  - "JSON parsing error : ..."
  - "JSON parsing error : ... at line L, column C: syntax error while parsing value - unexpected ']'; expected '[', '{' or a literal"
  - "JSON parsing error : ... at line L, column C: syntax error while parsing value - unexpected '{'; expected ']'"
  - usw...
  -> alle diese Fehler sind Syntax-Fehler und können mit Hilfe der oben genannten Website behoben werden

EIN MELDUNGSFENSTER WIRD ANGEZEIGT:
  - Dort steht normalerweise, was zu tun ist
  - Ansonsten die Datei ./log.txt überprüfen (neu laden, falls sie noch geöffnet war), sie darf keine ERRORs beinhalten.
  - Sie sollten auch alle WARNINGs beheben

ASI LOADER ERROR:
  Bitte melden Sie diesen Fehler und laden Sie "default.json" auf den SU-discord Server unter Development/s4-Hotkeys hoch

FUNKTIONIERT IMMER NOCH NICHT:
  - löschen/umbenennen Sie die "default.json"-Datei und starten Sie S4 (oder den ganzen PC) neu, es wird sie mit den Standardeinstellungen neu generieren...
  - diesen Fehler melden und "default.json" auf den SU-discord Server unter Development/s4-Hotkeys hochladen oder

PERFORMANCE:
  - wenn der PC vermutlich durch die Advanced Hotkeys langsamer wird, v.a. beim DEBUGGEN, versuche zuerst "Use Mouse Hook" zu deaktivieren (standardgemäß deaktiviert), sonst danach "Use Windows Hook" zu ändern, aktiviert sollte jedoch im Normalfall performanter sein (in den Einstellungen im Spiel (HD Patch) unter "External -> Hotkeys" oder manuell in der Windows Registry (siehe unten)).
  Wenn aktiviert (empfohlen), wird der standardmäßige Windows-Hook verwendet, der viel leistungsfähiger sein sollte und es z.B. erlaubt, eine Taste gedrückt zu halten sowie mehrere Hotkeys gleichzeitig zu drücken. Andernfalls, wenn deaktiviert, kann nur ein Hotkey gleichzeitig gedrückt werden, da eine andere Technik im Hintergrund verwendet wird.

UNERWARTETE ERGEBNISSE:
  - wenn Standard-Tasten nicht das tun, was sie sollten - und das kein Fehler der default.json-Datei ist, kann die Änderung vom Parameter "Ignore S4 Special Keys" helfen (in den Einstellungen im Spiel (HD Patch) unter "External -> Hotkeys" oder manuell in der Windows Registry (siehe unten)).





### MANUELLE ÄNDERUNG IN DER WINDOWS REGISTRY
Falls der HD Patch nicht verwendet wird und daher die Einstellungen nicht im Spiel selbst geändert werden können, können sie momentan nur über die Windows Registry bearbeitet werden.
Wichtig: Einträge in der Registry werden erst nach dem ersten Starten von S4 erstellt.

"Windows-Key + R" drücken
"regedit" eingeben
"OK" drücken
Navigiere zu "Computer\HKEY_CURRENT_USER\Software\Settlers United\S4\Game"
Klick auf "Game"
Doppelklick auf besagten key (Spalte "Name", z.B. "IgnoreS4SpecialKeys")
0 oder 1 als Wert eingeben (1 bedeutet "aktiviert")
"OK" drücken
S4 neustarten

Für genauere Informationen siehe https://www.bleepingcomputer.com/tutorials/how-to-use-the-windows-registry-editor/





### NÜTZLICHE LINKS
Einführung in json: https://www.json.org/json-en.html
Überprüfen Sie Ihre json-Datei: https://jsonlint.com/
Virtuelle Schlüssel-Codes: https://learn.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes
Deutsches Keyboard Layout: https://kbdlayout.info/KBDGR/virtualkeys
US English Keyboard Layout: https://kbdlayout.info/kbdusa/virtualkeys
How to change Registry entries: https://www.bleepingcomputer.com/tutorials/how-to-use-the-windows-registry-editor/

