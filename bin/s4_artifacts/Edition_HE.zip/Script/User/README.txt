Place any user-created map scripts (.txt) here.


==============================================================
Only Lua Scripts placed IN THIS FOLDER (or any subfolder of it) can be loaded by the Settlers United Lobby-option "Lua Script".
This of course does NOT affect map files.
